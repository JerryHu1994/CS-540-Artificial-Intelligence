/**
 * An enumeration representing the two classes of interest.
 * 
 * DO NOT MODIFY
 */
public enum Label {
	Negative, Positive
}
